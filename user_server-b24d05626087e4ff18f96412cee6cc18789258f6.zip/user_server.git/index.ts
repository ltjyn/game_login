import path = require('path');
export var sourceRoot:string = path.resolve(__dirname);