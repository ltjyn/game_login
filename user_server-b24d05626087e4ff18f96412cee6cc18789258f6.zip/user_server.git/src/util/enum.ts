/**
 * 游戏用到的所有枚举类型定义
 */

export enum ROLE_ST {
    NORMAL = 0,
    FORBID = 1,
    BAN_SPEAK = 2,
    COUNT
}

export enum HTTP_RES_DATA_TYPE {
    JSON = 0,
    RAW_DATA = 1
}




