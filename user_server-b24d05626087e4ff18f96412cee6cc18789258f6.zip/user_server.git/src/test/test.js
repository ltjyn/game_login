//var url = require('url');
//var urlData = url.parse('http://123.123.13.1:8080/Proj/Game/Game1/Abc.action');
//var ctlName = urlData.pathname;          //去掉controller路径的第一个'/'
//ctlName = ctlName.replace(/\/+/g, '');
//ctlName = ctlName.replace(/\/+$/g, '');
//
//console.log(ctlName);

console.log(new Date().valueOf()/1000);