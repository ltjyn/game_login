import express = require('express');
import http = require('http');
import https = require('https');
import bodyParser = require('body-parser');
import log = require('../util/log');
import Router = require('./router');
import compression = require('compression');
import index = require('../../index');
var fs = require('fs');

class HttpServer {
    app:express.Express = null;
    config:any = null;

    public start(config:any,
                 cb:(err)=>void):void {
        this.config = config;
        this.app = express();
        this.app.set('port', config['port']);

        var logs = log.getLogger();
        for(var c in logs){
            this.app.use(logs[c]);
        }

        this.app.use(compression());
        this.app.use(bodyParser.json({limit: '1mb'}));
        this.app.use(bodyParser.urlencoded({extended: true, limit: '10mb'}));
        if (config['bAllowCrossdomain']) {
            this.app.use((req:express.Request, res:express.Response, next)=> {
                var origin = (req.headers['origin'] || "*");
                res.header("Access-Control-Allow-Credentials", 'true');
                res.header("Access-Control-Allow-Origin", origin);
                res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS");
                res.header("Access-Control-Allow-Headers", "*");
                res.header("Content-Type", "application/json;charset=utf-8");
                if ("OPTIONS" == req.method) {
                    res.send(200);
                } else {
                    next();
                }
            });
        }

        this.app.all("/*", Router.index);

        if(typeof config['isHttps'] === 'undefined' || config['isHttps'] === false){
            http.createServer(this.app).listen(this.app.get("port"), () => {
                log.sInfo('start', 'http server is now listening on ' + this.config['port']);
                cb(null);
            });
        }
        else{
            var dataPath = index.sourceRoot + '/ssl/';
            var options = {
                key: fs.readFileSync(dataPath + '2_moltentec.com.key'),
                cert: fs.readFileSync(dataPath + '1_moltentec.com_bundle.crt')
            };

            https.createServer(options, this.app).listen(this.app.get("port"), ()=>{
                log.sInfo('start ', 'https server is now listening on ' + this.config['port']);
                cb(null);
            });
        }
    }
}

export = HttpServer;